// AYA RAHMOUN
package task2

import scala.collection.mutable.Queue
import scala.collection.mutable.Set

class MyNode(id: String, memory: Int, neighbours: Vector[String], router: Router) extends Node(id, memory, neighbours, router) {
    val STORE = "STORE"
    val STORE_SUCCESS = "STORE_SUCCESS"
    val STORE_FAILURE = "STORE_FAILURE"
    val RETRIEVE = "RETRIEVE"
    val GET_NEIGHBOURS = "GET_NEIGHBOURS"
    val NEIGHBOURS_RESPONSE = "NEIGHBOURS_RESPONSE"
    val RETRIEVE_SUCCESS = "RETRIEVE_SUCCESS"
    val RETRIEVE_FAILURE = "RETRIEVE_FAILURE"
    val INTERNAL_ERROR = "INTERNAL_ERROR"
    val USER = "USER"
    val nodes_may_fail = 4


    override def onReceive(from: String, message: Message): Message = {
        /* 
         * Called when the node receives a message from some where
         * Feel free to add more methods and code for processing more kinds of messages
         * NOTE: Remember that HOST must still comply with the specifications of USER messages
         *
         * Parameters
         * ----------
         * from: id of node from where the message arrived
         * message: the message
         *           (Process this message and decide what to do)
         *           (All communication between peers happens via these messages)
         */
        if (message.messageType == GET_NEIGHBOURS) { // Request to get the list of neighbours
            new Message(id, NEIGHBOURS_RESPONSE, neighbours.mkString(" "))
        }
        else if (message.messageType == RETRIEVE) { // Request to get the value
            val key = message.data // This is the key
            val value = getKey(key) // Check if the key is present on the node
            var response : Message = new Message("", "", "")
            value match {
                case Some(i) => response = new Message(id, RETRIEVE_SUCCESS, i)
                case None => response = new Message(id, RETRIEVE_FAILURE)
            }
            if (response.messageType == RETRIEVE_FAILURE) {
                if (from == USER){
                    var queue = Queue[String]()
                    var set = Set[String]()
                    set+=id

                    for( x <- neighbours )
                        queue.enqueue(x)

                    while (!queue.isEmpty && response.messageType == RETRIEVE_FAILURE){
                        var curr_node = queue.dequeue
                        if(!set.contains(curr_node))
                            set +=curr_node
                            response = router.sendMessage(id, curr_node, new Message(id, message.messageType, message.data))
                            for (n <- (response.data.split(' '))){
                                if ((set.contains(n)) == false && queue.contains(n)== false) {
                                    queue.enqueue(n)        
                                }
                            }   
                    }
                } 
                else {
                    response = new Message(id, RETRIEVE_FAILURE, neighbours.mkString(" "))
                }
            }
            response  // Return the correct response message
            /*
             * TODO: task 2.1
             * Add retrieval algorithm to retrieve from the peers here
             * when the key isn't available on the HOST node.
             * Use router.sendMessage(from, to, message) to send a message to another node
             */
        }

        else if (message.messageType == STORE) { // Request to store key->value
            
            /*
             * TODO: task 2.2
             * Change the storage algorithm below to store on the peers
             * when there isn't enough space on the HOST node.
             *
             * TODO: task 2.3
             * Change the storage algorithm below to handle nodes crashing.
             */

            val data = message.data.split("->") // data(0) is key, data(1) is value
            val storedOnSelf = setKey(data(0), data(1)) // Store on current node
            var response : Message = new Message("", "", "")

            /* if (storedOnSelf) {
                response = new Message(id, STORE_SUCCESS)
            } */
            /* else {
                response = new Message(id, STORE_FAILURE)
            } */

            if (from == USER) {
                var queue = Queue[String]()
                var set = Set[String]()
                var count = 0
                set+=id

                if (storedOnSelf) {
                    count = 1
                } 

                for( x <- neighbours )
                    queue.enqueue(x)
                while (!queue.isEmpty && count<5){
                    var curr_node = queue.dequeue
                    set +=curr_node
                    response = router.sendMessage(id, curr_node, message)
                    if (response.messageType == STORE_SUCCESS){
                        count +=1
                    }
                    for (n <- (response.data.split(' '))) {
                        if ((set.contains(n)) == false && queue.contains(n)== false) 
                            queue.enqueue(n)
                    }    
                }
                if (count == 5){
                    response = new Message(id, STORE_SUCCESS)
                } 
                else{
                    response = new Message(id, STORE_FAILURE)
                }
            }
            else {
                if (storedOnSelf) {
                    response = new Message(id, STORE_SUCCESS, neighbours.mkString(" "))
                }
                else {
                    response = new Message(id, STORE_FAILURE, neighbours.mkString(" "))
                }
            }
            response
        }
        /*
         * Feel free to add more kinds of messages.
         */
        else
            new Message(id, INTERNAL_ERROR)
    }
}